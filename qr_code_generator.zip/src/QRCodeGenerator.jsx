import { useState, useRef } from "react";
import QRCode from "qrcode.react";

export default function QRCodeGenerator() {
  const [text, setText] = useState("");
  const qrRef = useRef(null);

  const downloadQR = () => {
    const canvas = qrRef.current.querySelector("canvas");
    const url = canvas.toDataURL("image/png");
    const link = document.createElement("a");
    link.href = url;
    link.download = "qrcode.png";
    link.click();
  };

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", padding: "2rem", background: "#f3f4f6" }}>
      <h1 style={{ fontSize: "2rem", fontWeight: "bold", marginBottom: "2rem" }}>QR Code Generator</h1>
      <div style={{ width: "100%", maxWidth: "400px" }}>
        <input
          style={{ padding: "0.5rem", width: "100%", borderRadius: "0.5rem", marginBottom: "1rem", border: "1px solid #ccc" }}
          placeholder="Enter text or URL..."
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        {text && (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "1rem" }}>
            <div ref={qrRef} style={{ background: "#fff", padding: "1rem", borderRadius: "1rem", boxShadow: "0 4px 6px rgba(0,0,0,0.1)" }}>
              <QRCode value={text} size={256} includeMargin={true} />
            </div>
            <button onClick={downloadQR} style={{ padding: "0.5rem 1rem", background: "#2563eb", color: "white", border: "none", borderRadius: "0.5rem" }}>
              Download QR Code
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
